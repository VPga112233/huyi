"""PixelShield Automated Legal Takedown & Cybercrime Bundler (Feature 09).
Auto-populates legally enforceable takedown notices and police complaint forms under
Indian IT Act 2000 (Sec 66E, 67A, 79(3)(b)) & Intermediary Guidelines Rules 2021.
"""
from typing import Dict, Any, List
from datetime import datetime, timezone
from app.config import settings
from app.core.i18n import t


class LegalTakedownBuilder:
    """
    Generates formal legal notices, intermediary takedown demands (Rule 3(2)(b)),
    and cybercrime.gov.in complaint bundles.
    """

    @classmethod
    def generate_cybercrime_portal_payload(cls, case_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Structures incident complaint ready for India's National Cyber Crime Portal (cybercrime.gov.in).
        """
        timestamp = case_data.get("timestamp") or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        return {
            "portal": "https://cybercrime.gov.in",
            "complaint_category": "Crime Against Women & Children (Non-Consensual Imagery / Deepfake Morphing)",
            "sub_category": "Publishing / Transmitting Obscene or Explicit Material in Electronic Form",
            "incident_date_time": timestamp,
            "suspect_platform": case_data.get("platform_name", "Social Media"),
            "suspect_url_link": case_data.get("platform_url", ""),
            "suspect_profile_handle": case_data.get("perpetrator_handle", ""),
            "applicable_statutes": [
                "Section 66E, Information Technology Act, 2000 (Violation of Privacy)",
                "Section 67A, Information Technology Act, 2000 (Sexually Explicit Material)",
                "Section 354D, Indian Penal Code / Section 78 Bharatiya Nyaya Sanhita, 2023 (Cyber Stalking)",
                "Section 509, Indian Penal Code / Section 79 Bharatiya Nyaya Sanhita, 2023 (Insult to Modesty)",
            ],
            "evidence_attachment": {
                "vault_case_id": case_data.get("case_id", "N/A"),
                "sha256_hash": case_data.get("sha256", "N/A"),
                "tamper_seal": case_data.get("tamper_seal", "N/A"),
                "statutory_cert_65b": "Section 65B Electronic Record Dossier Attached",
            },
            "brief_description": (
                f"The complainant's image has been morphed/synthesized without authorization and posted at "
                f"{case_data.get('platform_url', 'the linked address')}. This constitutes a severe privacy violation and criminal "
                f"harassment under Sections 66E & 67A of the IT Act. The complainant requests immediate FIR registration "
                f"and preservation of IP access logs from the intermediary."
            ),
        }

    @classmethod
    def generate_platform_notice(
        cls,
        platform: str,
        case_data: Dict[str, Any],
        lang: str = "en"
    ) -> Dict[str, Any]:
        """
        Generates platform-specific legal notice demanding takedown within 24 hours
        under Rule 3(2)(b) of IT (Intermediary Guidelines) Rules, 2021.
        """
        platform_lower = platform.lower()
        now_str = datetime.now(timezone.utc).strftime("%d %B %Y %H:%M:%S UTC")
        case_id = case_data.get("case_id", "PS-CASE-PENDING")
        url = case_data.get("platform_url", "URL_NOT_PROVIDED")
        handle = case_data.get("perpetrator_handle", "UNKNOWN_ACCOUNT")
        sha256_val = case_data.get("sha256", "N/A")

        if "instagram" in platform_lower or "meta" in platform_lower:
            recipient = "Meta Platforms Grievance Officer (India) / legal@instagram.com"
            policy_ref = "Meta Non-Consensual Intimate Imagery (NCII) & Impersonation Policy"
        elif "x" in platform_lower or "twitter" in platform_lower:
            recipient = "X Corp Grievance Officer (India) / grievance-officer-india@x.com"
            policy_ref = "X Synthetic and Manipulated Media & Non-Consensual Nudity Policy"
        elif "telegram" in platform_lower:
            recipient = "Telegram Messenger Legal & Abuse / abuse@telegram.org / stopca@telegram.org"
            policy_ref = "Telegram Terms of Service (Prohibited Non-Consensual Imagery)"
        else:
            recipient = "Designated Intermediary Grievance Officer"
            policy_ref = "IT Act Intermediary Compliance"

        subject = f"URGENT STATUTORY TAKEDOWN NOTICE (24-HR DEADLINE): IT ACT SEC 66E/67A & RULE 3(2)(b) - CASE {case_id}"

        legal_notice_body = f"""
TO: {recipient}
DATE: {now_str}
SUBJECT: {subject}

NOTICE UNDER RULE 3(2)(b) OF THE INFORMATION TECHNOLOGY (INTERMEDIARY GUIDELINES AND DIGITAL MEDIA ETHICS CODE) RULES, 2021 READ WITH SECTIONS 66E & 67A OF THE INFORMATION TECHNOLOGY ACT, 2000.

Dear Grievance Officer,

1. This is a formal legal notice regarding non-consensual imagery / AI synthetic manipulation (deepfake) hosted on your platform targeting the complainant:
   - Infringing URL: {url}
   - Infringing Account / Handle: {handle}
   - Evidence SHA-256 Digest: {sha256_val}
   - PixelShield Forensic Case Ref: {case_id}

2. STATUTORY MANDATE FOR EXPEDITED REMOVAL (24 HOURS):
   Under Rule 3(2)(b) of the Information Technology Intermediary Rules, 2021, an intermediary is legally mandated to remove or disable access to any material that exposes the private area of any person, shows such person in full or partial nudity, or in any sexual act, or is in the nature of impersonation, WITHIN TWENTY-FOUR (24) HOURS from the receipt of a complaint.

3. CRIMINAL OFFENSES COMMITTED:
   - Section 66E, IT Act 2000: Violation of bodily privacy (cognizable offense).
   - Section 67A, IT Act 2000: Transmission of sexually explicit content (punishable up to 5 years imprisonment).
   - Section 79(3)(b), IT Act 2000: Failure to remove content upon notice forfeits statutory safe-harbor intermediary immunity.

4. REQUIRED ACTIONS:
   a. Immediately disable/takedown the infringing content at {url}.
   b. Suspend the offending account ({handle}) to prevent further dissemination.
   c. Preserve server transaction logs, IP addresses, and upload timestamps for submission to law enforcement under Section 91 CrPC / Section 94 BNSS.

Failure to comply within the 24-hour statutory window will lead to appropriate legal proceedings before competent courts and law enforcement authorities, wherein intermediary immunity shall not be available.

PixelShield Digital Trust & Safety Enclave
(On behalf of the affected individual)
Helpline: 1930 | cybercrime.gov.in
"""

        return {
            "platform": platform,
            "recipient_officer": recipient,
            "subject": subject,
            "statutory_deadline": "24 Hours from receipt under Rule 3(2)(b)",
            "policy_violation": policy_ref,
            "notice_text": legal_notice_body.strip(),
            "cybercrime_portal_ready": cls.generate_cybercrime_portal_payload(case_data),
        }


takedown_builder = LegalTakedownBuilder()
