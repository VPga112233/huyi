"""PixelShield One-Tap Cryptographic Evidence Vault (Feature 08).
Generates tamper-sealed, court-admissible forensic dossiers compliant with
Section 65B Indian Evidence Act / Section 63 Bharatiya Sakshya Adhiniyam (BSA), 2023.
"""
import io
import os
import zipfile
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Tuple

from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether, HRFlowable

from app.config import settings
from app.core.security import compute_sha256, compute_sha512, create_tamper_seal, generate_vault_id


class EvidenceVaultService:
    """
    Builds digitally sealed evidence packages containing forensic dossiers,
    chain-of-custody manifests, and cryptographic verification seals.
    """

    @classmethod
    def generate_dossier_pdf(cls, evidence_data: Dict[str, Any]) -> bytes:
        """
        Renders a formal Section 65B Electronic Evidence Dossier using ReportLab.
        """
        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf,
            pagesize=letter,
            rightMargin=0.5 * inch,
            leftMargin=0.5 * inch,
            topMargin=0.5 * inch,
            bottomMargin=0.5 * inch
        )

        styles = getSampleStyleSheet()

        title_style = ParagraphStyle(
            "DocTitle",
            parent=styles["Heading1"],
            fontSize=16,
            leading=20,
            textColor=colors.HexColor("#0D1B2A"),
            alignment=1, # Center
            spaceAfter=6
        )

        subtitle_style = ParagraphStyle(
            "DocSubtitle",
            parent=styles["Normal"],
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#415A77"),
            alignment=1,
            spaceAfter=12
        )

        h2_style = ParagraphStyle(
            "Heading2Custom",
            parent=styles["Heading2"],
            fontSize=11,
            leading=14,
            textColor=colors.HexColor("#1B263B"),
            spaceBefore=8,
            spaceAfter=4
        )

        body_style = ParagraphStyle(
            "BodyCustom",
            parent=styles["Normal"],
            fontSize=8.5,
            leading=11,
            textColor=colors.HexColor("#1F2937")
        )

        legal_cert_style = ParagraphStyle(
            "LegalCertStyle",
            parent=styles["Normal"],
            fontSize=8,
            leading=10.5,
            textColor=colors.HexColor("#374151")
        )

        story = []

        # Header Badge
        story.append(Paragraph("<b>PIXELSHIELD CYBERCRIME FORENSIC EVIDENCE VAULT</b>", title_style))
        story.append(Paragraph(
            "<b>STATUTORY ELECTRONIC EVIDENCE CERTIFICATE & FORENSIC CHAIN OF CUSTODY</b><br/>"
            "Compliant with Section 65B of Indian Evidence Act, 1872 / Section 63 of Bharatiya Sakshya Adhiniyam, 2023",
            subtitle_style
        ))
        story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#0D1B2A"), spaceAfter=10))

        # Case Meta Summary Table
        meta_data = [
            [
                Paragraph("<b>Case Reference ID:</b>", body_style),
                Paragraph(f"<code>{evidence_data.get('case_id', 'N/A')}</code>", body_style),
                Paragraph("<b>Creation Timestamp (UTC):</b>", body_style),
                Paragraph(evidence_data.get("timestamp_utc", datetime.now(timezone.utc).isoformat()), body_style),
            ],
            [
                Paragraph("<b>Incident Category:</b>", body_style),
                Paragraph(evidence_data.get("incident_type", "AI Deepfake / Non-Consensual Imagery"), body_style),
                Paragraph("<b>Jurisdiction:</b>", body_style),
                Paragraph("Republic of India / IT Act 2000", body_style),
            ],
            [
                Paragraph("<b>Target Platform:</b>", body_style),
                Paragraph(evidence_data.get("platform_name", "Instagram / Telegram / Web"), body_style),
                Paragraph("<b>Perpetrator Handle / URL:</b>", body_style),
                Paragraph(evidence_data.get("platform_url", "Reported in Complaint"), body_style),
            ],
        ]

        meta_table = Table(meta_data, colWidths=[1.4 * inch, 2.3 * inch, 1.5 * inch, 2.3 * inch])
        meta_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F8FAFC")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(meta_table)
        story.append(Spacer(1, 8))

        # Cryptographic Hash & Tamper Seal Section
        story.append(Paragraph("<b>1. Cryptographic Fingerprints & Tamper-Evident Seals</b>", h2_style))
        hash_data = [
            [
                Paragraph("<b>Primary SHA-256 Digest:</b>", body_style),
                Paragraph(f"<font size=7><code>{evidence_data.get('sha256', 'N/A')}</code></font>", body_style)
            ],
            [
                Paragraph("<b>Meta 256-bit PDQ Hash:</b>", body_style),
                Paragraph(f"<font size=7><code>{evidence_data.get('pdq_hash', 'N/A')}</code></font>", body_style)
            ],
            [
                Paragraph("<b>Standard pHash (DCT 64-bit):</b>", body_style),
                Paragraph(f"<font size=7><code>{evidence_data.get('phash', 'N/A')}</code></font>", body_style)
            ],
            [
                Paragraph("<b>Zero-Knowledge Blinded Token:</b>", body_style),
                Paragraph(f"<font size=7><code>{evidence_data.get('blinded_token', 'N/A')}</code></font>", body_style)
            ],
            [
                Paragraph("<b>HMAC-SHA256 Tamper Seal:</b>", body_style),
                Paragraph(f"<font size=7 color='#0284C7'><b><code>{evidence_data.get('tamper_seal', 'N/A')}</code></b></font>", body_style)
            ]
        ]
        hash_table = Table(hash_data, colWidths=[2.2 * inch, 5.3 * inch])
        hash_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F1F5F9")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#94A3B8")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(hash_table)
        story.append(Spacer(1, 8))

        # Forensic Findings Section
        story.append(Paragraph("<b>2. Automated Forensic Findings & Authenticity Assessment</b>", h2_style))
        forensics = evidence_data.get("forensics", {})
        forensic_data = [
            [
                Paragraph("<b>Forensic Metric</b>", body_style),
                Paragraph("<b>Score / Finding</b>", body_style),
                Paragraph("<b>Diagnostic Interpretation</b>", body_style)
            ],
            [
                Paragraph("<b>Synthetic Confidence</b>", body_style),
                Paragraph(forensics.get("synthetic_confidence_score", "N/A"), body_style),
                Paragraph("Probabilistic confidence of AI generation or morphing.", body_style)
            ],
            [
                Paragraph("<b>Error Level Analysis (ELA)</b>", body_style),
                Paragraph(forensics.get("forensic_streams", {}).get("error_level_analysis", {}).get("score", "N/A"), body_style),
                Paragraph("Measures compression grid irregularities indicating localized splicing.", body_style)
            ],
            [
                Paragraph("<b>FFT High-Frequency Analysis</b>", body_style),
                Paragraph(forensics.get("forensic_streams", {}).get("fft_frequency_analysis", {}).get("score", "N/A"), body_style),
                Paragraph("Detects periodic checkerboard grid artifacts typical of diffusion models.", body_style)
            ],
            [
                Paragraph("<b>Facial Boundary Discontinuity</b>", body_style),
                Paragraph(forensics.get("forensic_streams", {}).get("facial_boundary_detection", {}).get("score", "N/A"), body_style),
                Paragraph("Detects gradient step transitions characteristic of face swap seams.", body_style)
            ],
        ]
        forensic_table = Table(forensic_data, colWidths=[2.0 * inch, 1.5 * inch, 4.0 * inch])
        forensic_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E2E8F0")),
            ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#64748B")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E1")),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(forensic_table)
        story.append(Spacer(1, 8))

        # Statutory 65B Certificate Section
        story.append(Paragraph("<b>3. Statutory Certificate Under Section 65B Indian Evidence Act, 1872</b>", h2_style))
        cert_text = (
            "I hereby certify and declare that the electronic records, cryptographic hashes, and forensic metrics "
            "detailed in this document were produced automatically by the PixelShield Cryptographic Evidence System "
            "during the ordinary course of its automated verification operations. The electronic computing devices, "
            "hashing routines (SHA-256 / PDQ), and integrity verification algorithms were operating properly and securely "
            "at all relevant times without unauthorized interference. Any alteration of the subject binary data will "
            "permanently invalidate the HMAC-SHA256 tamper seal recorded above. This certificate satisfies the statutory "
            "requirements for admissibility of electronic evidence under Section 65B of the Indian Evidence Act, 1872 "
            "(and Section 63 of the Bharatiya Sakshya Adhiniyam, 2023)."
        )
        story.append(Paragraph(cert_text, legal_cert_style))
        story.append(Spacer(1, 10))

        # Signature & Seal Box
        sig_data = [
            [
                Paragraph("<b>Automated Evidence Authority:</b> PixelShield Secure Enclave", body_style),
                Paragraph("<b>Verification Helpline:</b> 1930 / cybercrime.gov.in", body_style)
            ],
            [
                Paragraph("<b>Status:</b> DIGITALLY SEALED & ARCHIVED", body_style),
                Paragraph(f"<b>Seal Certificate ID:</b> <code>{evidence_data.get('cert_id', 'CERT-65B-GEN')}</code>", body_style)
            ]
        ]
        sig_table = Table(sig_data, colWidths=[3.75 * inch, 3.75 * inch])
        sig_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FEF2F2")),
            ("BOX", (0, 0), (-1, -1), 1, colors.HexColor("#EF4444")),
            ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#FCA5A5")),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        story.append(sig_table)

        doc.build(story)
        return buf.getvalue()

    @classmethod
    def create_evidence_package(
        cls,
        case_info: Dict[str, Any],
        image_bytes: bytes,
        forensic_results: Dict[str, Any] = None
    ) -> Tuple[str, str, Dict[str, Any]]:
        """
        Creates a complete cryptographic evidence package (.ZIP) containing:
        1. forensic_dossier.pdf (Section 65B certified)
        2. chain_of_custody_manifest.json
        3. tamper_seal.sig
        4. incident_summary.txt
        Returns:
            - case_id
            - zip_file_path
            - evidence_metadata
        """
        case_id = generate_vault_id()
        cert_id = f"CERT-65B-{case_id[9:]}"
        timestamp_utc = datetime.now(timezone.utc).isoformat()

        # Compute Hashes
        sha256_val = compute_sha256(image_bytes)
        sha512_val = compute_sha512(image_bytes)

        # Build payload for tamper seal
        payload = {
            "case_id": case_id,
            "cert_id": cert_id,
            "timestamp_utc": timestamp_utc,
            "incident_type": case_info.get("incident_type", "AI Image Manipulation / Non-Consensual Imagery"),
            "platform_name": case_info.get("platform_name", "Web / Social"),
            "platform_url": case_info.get("platform_url", "N/A"),
            "sha256": sha256_val,
            "sha512": sha512_val,
            "pdq_hash": case_info.get("pdq_hash", "N/A"),
            "phash": case_info.get("phash", "N/A"),
            "blinded_token": case_info.get("blinded_token", "N/A"),
        }

        # Sign with tamper seal
        canonical_str, tamper_signature = create_tamper_seal(payload)
        payload["tamper_seal"] = tamper_signature
        payload["forensics"] = forensic_results or {}

        # Generate PDF Dossier
        pdf_bytes = cls.generate_dossier_pdf(payload)

        # Generate Chain of Custody Manifest JSON
        manifest = {
            "evidence_vault_protocol": "PixelShield-Evidence-v1",
            "statutory_compliance": "Section 65B Indian Evidence Act / Section 63 BSA 2023",
            "case_id": case_id,
            "certificate_id": cert_id,
            "timestamp_utc": timestamp_utc,
            "hashes": {
                "sha256": sha256_val,
                "sha512": sha512_val,
                "pdq_256bit": payload["pdq_hash"],
                "phash_64bit": payload["phash"],
            },
            "tamper_seal_hmac_sha256": tamper_signature,
            "chain_of_custody_events": [
                {
                    "event": "EVIDENCE_INGESTED_AND_HASHED",
                    "actor": "PixelShield Cryptographic Enclave",
                    "timestamp": timestamp_utc,
                    "status": "VERIFIED_TAMPER_SEALED"
                }
            ],
            "legal_hotlines": {
                "national_cyber_crime": "1930",
                "national_portal": "https://cybercrime.gov.in",
                "ncw_women_helpline": "7827170170"
            }
        }

        manifest_bytes = json.dumps(manifest, indent=2).encode("utf-8")
        sig_bytes = f"PIXELSHIELD-TAMPER-SEAL: {tamper_signature}\nCASE-ID: {case_id}\nTIMESTAMP: {timestamp_utc}".encode("utf-8")

        summary_text = (
            f"PIXELSHIELD CRIME EVIDENCE VAULT DOSSIER\n"
            f"Case ID: {case_id}\n"
            f"Certificate ID: {cert_id}\n"
            f"Date / Time: {timestamp_utc}\n"
            f"Incident: {payload['incident_type']}\n"
            f"Target URL: {payload['platform_url']}\n"
            f"SHA-256 Digest: {sha256_val}\n"
            f"Tamper Seal: {tamper_signature}\n\n"
            f"Use this evidence package when filing a complaint at https://cybercrime.gov.in or calling 1930."
        ).encode("utf-8")

        # Create ZIP Archive in VAULT_DIR
        zip_filename = f"{case_id}.zip"
        zip_path = settings.VAULT_DIR / zip_filename

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zip_f:
            zip_f.writestr("forensic_dossier.pdf", pdf_bytes)
            zip_f.writestr("chain_of_custody_manifest.json", manifest_bytes)
            zip_f.writestr("tamper_seal.sig", sig_bytes)
            zip_f.writestr("incident_summary.txt", summary_text)

        pdf_filename = f"{case_id}_dossier.pdf"
        pdf_path = settings.VAULT_DIR / pdf_filename
        with open(pdf_path, "wb") as f:
            f.write(pdf_bytes)

        payload["zip_filename"] = zip_filename
        payload["pdf_filename"] = pdf_filename
        payload["zip_path"] = str(zip_path)

        return case_id, str(zip_path), payload


evidence_vault = EvidenceVaultService()
