"""PixelShield Non-Reversible Fingerprint Blocking Engine (Feature 07).
Implements StopNCII-style dual perceptual hashing:
1. Exact-Match Cryptographic SHA-256
2. Facebook / Meta 256-bit PDQ Perceptual Hash
3. DCT / Wavelet perceptual hashes (pHash, dHash, wHash)
4. Non-reversible zero-knowledge platform blocking tokens
"""
import io
import math
from typing import Dict, Any, Tuple, Optional
import numpy as np
from PIL import Image
import imagehash
from scipy.fftpack import dct

from app.core.security import compute_sha256, generate_blinded_token
from app.config import settings


def compute_pdq_hash(image: Image.Image) -> str:
    """
    Implementation of Meta / Facebook's 256-bit PDQ (Perceptual Discrete Cosine) Hashing algorithm.
    1. Converts image to greyscale luminance.
    2. Resamples to standard 64x64 buffer with bilateral / area averaging.
    3. Computes 2D Discrete Cosine Transform (DCT-II).
    4. Extracts 16x16 low-to-mid frequency AC coefficients (excluding DC).
    5. Thresholds against the median coefficient to produce 256 binary bits (64 hex characters).
    """
    # Convert to greyscale
    gray = image.convert("L")
    # Resize to 64x64
    resized = gray.resize((64, 64), Image.Resampling.BILINEAR)
    arr = np.asarray(resized, dtype=np.float64)

    # 2D DCT (ortho normalized)
    dct_rows = dct(arr, type=2, axis=0, norm="ortho")
    dct_2d = dct(dct_rows, type=2, axis=1, norm="ortho")

    # Extract 16x16 low/mid frequency block (indices 1 to 16, ignoring [0,0] DC term)
    sub_block = dct_2d[1:17, 1:17]

    # Median threshold
    median_val = float(np.median(sub_block))
    bit_array = (sub_block > median_val).flatten()

    # Convert 256 bits into 64-character hex string (32 bytes)
    bit_str = "".join(["1" if b else "0" for b in bit_array])
    hex_str = f"{int(bit_str, 2):064x}"
    return hex_str


def hamming_distance_hex(hex_a: str, hex_b: str, bit_length: int = 256) -> int:
    """Computes bitwise Hamming distance between two hex-encoded hash strings."""
    int_a = int(hex_a, 16)
    int_b = int(hex_b, 16)
    xor_val = int_a ^ int_b
    return bin(xor_val).count("1")


class FingerprintEngine:
    """
    Perceptual Fingerprinting Suite generating both exact and look-alike hashes.
    """

    @classmethod
    def generate_fingerprints(cls, image_bytes: bytes) -> Dict[str, Any]:
        """
        Extracts full cryptographic and perceptual fingerprint bundle:
        - Exact SHA-256
        - Meta 256-bit PDQ Hash
        - pHash (DCT 64-bit)
        - dHash (Gradient Difference 64-bit)
        - wHash (Wavelet 64-bit)
        - StopNCII-style Zero-Knowledge Blinded Platform Token
        """
        # Exact cryptographic hash
        sha256_hash = compute_sha256(image_bytes)

        # Open image with PIL
        pil_img = Image.open(io.BytesIO(image_bytes))

        # Perceptual hashes
        pdq_hash = compute_pdq_hash(pil_img)
        phash_val = str(imagehash.phash(pil_img))
        dhash_val = str(imagehash.dhash(pil_img))
        whash_val = str(imagehash.whash(pil_img))

        # Non-reversible platform blocking token (HMAC-SHA256 blinded)
        # This token allows platforms like Meta, X, and Reddit to match without having the image
        blinded_token = generate_blinded_token(pdq_hash)

        return {
            "exact_sha256": sha256_hash,
            "pdq_hash_256bit": pdq_hash,
            "phash_64bit": phash_val,
            "dhash_64bit": dhash_val,
            "whash_64bit": whash_val,
            "blinded_blocking_token": blinded_token,
            "stopncii_compatible": True,
            "zero_knowledge_safe": True,
        }

    @classmethod
    def compare_fingerprints(
        cls,
        hash_bundle_a: Dict[str, Any],
        hash_bundle_b: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Compares two fingerprint bundles to determine if they represent the same photo,
        a cropped/compressed look-alike, or different subjects.
        """
        # Exact SHA-256 match
        exact_match = hash_bundle_a["exact_sha256"] == hash_bundle_b["exact_sha256"]

        # PDQ Hamming Distance (0 to 256)
        pdq_a = hash_bundle_a["pdq_hash_256bit"]
        pdq_b = hash_bundle_b["pdq_hash_256bit"]
        pdq_distance = hamming_distance_hex(pdq_a, pdq_b, bit_length=256)

        # pHash Hamming Distance (0 to 64)
        phash_a = hash_bundle_a["phash_64bit"]
        phash_b = hash_bundle_b["phash_64bit"]
        phash_distance = hamming_distance_hex(phash_a, phash_b, bit_length=64)

        is_pdq_match = pdq_distance <= settings.PDQ_HAMMING_THRESHOLD
        is_phash_match = phash_distance <= settings.PHASH_HAMMING_THRESHOLD

        is_lookalike_match = is_pdq_match or is_phash_match

        similarity_pct = round(max(0.0, (256.0 - pdq_distance) / 256.0 * 100.0), 2)

        verdict = (
            "EXACT_MATCH"
            if exact_match
            else "LOOKALIKE_MISUSE_DETECTED"
            if is_lookalike_match
            else "DISTINCT_IMAGE"
        )

        return {
            "verdict": verdict,
            "is_misuse_detected": exact_match or is_lookalike_match,
            "exact_sha256_match": exact_match,
            "pdq_hamming_distance": pdq_distance,
            "pdq_threshold": settings.PDQ_HAMMING_THRESHOLD,
            "phash_hamming_distance": phash_distance,
            "phash_threshold": settings.PHASH_HAMMING_THRESHOLD,
            "visual_similarity_pct": similarity_pct,
        }


fingerprint_engine = FingerprintEngine()
