"""PixelShield Core Security & Cryptography Module.
Implements non-reversible hash blinding, tamper seals, and chain-of-custody signatures.
"""
import hashlib
import hmac
import json
import base64
import time
import os
from typing import Dict, Any, Tuple
from app.config import settings


def compute_sha256(data: bytes) -> str:
    """Computes standard SHA-256 hex digest for binary image data."""
    return hashlib.sha256(data).hexdigest()


def compute_sha512(data: bytes) -> str:
    """Computes SHA-512 digest for forensic evidence integrity."""
    return hashlib.sha512(data).hexdigest()


def generate_blinded_token(raw_hash: str, salt: str = None) -> str:
    """
    Creates a non-reversible, zero-knowledge platform blocking token (StopNCII style).
    Platforms match against this HMAC-SHA256 blinded token without ever receiving
    the raw perceptual hash or the unshielded image.
    """
    if salt is None:
        salt = settings.HMAC_SALT_HASH
    return hmac.new(
        salt.encode("utf-8"),
        raw_hash.strip().lower().encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def create_tamper_seal(payload: Dict[str, Any], secret_key: str = None) -> Tuple[str, str]:
    """
    Generates a cryptographic tamper seal for an evidence record.
    Returns (canonical_json_string, hmac_signature).
    """
    if secret_key is None:
        secret_key = settings.SECRET_KEY
    canonical_payload = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    signature = hmac.new(
        secret_key.encode("utf-8"),
        canonical_payload.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    return canonical_payload, signature


def verify_tamper_seal(payload: Dict[str, Any], expected_signature: str, secret_key: str = None) -> bool:
    """Verifies that an evidence record has not been altered after creation."""
    if secret_key is None:
        secret_key = settings.SECRET_KEY
    canonical_payload = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    computed = hmac.new(
        secret_key.encode("utf-8"),
        canonical_payload.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    return hmac.compare_digest(computed, expected_signature)


def generate_vault_id() -> str:
    """Generates a cryptographically strong unique Vault Case identifier."""
    rand_bytes = os.urandom(8)
    timestamp_prefix = hex(int(time.time()))[2:]
    return f"PS-VAULT-{timestamp_prefix}-{rand_bytes.hex().upper()}"
