"""PixelShield Multilingual Localization Engine (Feature 13).
Supports English, Hindi (हिन्दी), Tamil (தமிழ்), Bengali (বাংলা), Telugu (తెలుగు), and Marathi (मराठी).
"""
import json
from pathlib import Path
from typing import Dict, Any

LOCALES_DIR = Path(__file__).resolve().parent.parent / "locales"

_CACHE: Dict[str, Dict[str, Any]] = {}


def load_locale(lang: str) -> Dict[str, Any]:
    """Loads and caches translation dictionary for specified language code."""
    lang = lang.lower().strip()
    if lang in _CACHE:
        return _CACHE[lang]

    filepath = LOCALES_DIR / f"{lang}.json"
    if not filepath.exists():
        # Fallback to English
        filepath = LOCALES_DIR / "en.json"

    if filepath.exists():
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
                _CACHE[lang] = data
                return data
        except Exception:
            pass

    return {}


def t(key: str, lang: str = "en", **kwargs) -> str:
    """
    Translates a localized string key with optional formatting arguments.
    Falls back gracefully: lang -> en -> raw key.
    """
    data = load_locale(lang)
    val = data.get(key)
    if val is None and lang != "en":
        en_data = load_locale("en")
        val = en_data.get(key)

    if val is None:
        val = key

    if kwargs:
        try:
            return val.format(**kwargs)
        except Exception:
            return val
    return val


def get_supported_languages() -> Dict[str, str]:
    return {
        "en": "English",
        "hi": "हिन्दी (Hindi)",
        "ta": "தமிழ் (Tamil)",
        "bn": "বাংলা (Bengali)",
        "te": "తెలుగు (Telugu)",
        "mr": "मराठी (Marathi)",
    }
