"""PixelShield Main Application.
Production-ready FastAPI application hosting all 4 defense layers & 13 essential features.
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import time

from app.config import settings
from app.api.v1.router import api_router
from app.models.base import init_db


# Ensure tables are initialized
init_db()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initializes database tables and verifies model integrity upon startup."""
    init_db()
    yield


app = FastAPI(
    title=settings.PROJECT_NAME,
    description=(
        "**PixelShield: Photo Shield - Protect Before You Post**\n\n"
        "A proactive early defense platform providing adversarial cloaking against deepfakes, "
        "social media compression stress testing, zero-knowledge perceptual fingerprinting, "
        "statutory Section 65B legal evidence dossiers, automated IT Act takedown bundling, "
        "multi-modal digital forensics, and blackmail crisis emergency SOS response."
    ),
    version=settings.VERSION,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Measures execution latency for security and throughput auditing."""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time-Sec"] = f"{process_time:.4f}"
    response.headers["X-PixelShield-Enclave"] = "Secure-ZeroKnowledge-v1"
    return response


# Include API v1 Router
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/", tags=["Root"])
def root():
    """PixelShield Root Information Endpoint."""
    return {
        "platform": settings.PROJECT_NAME,
        "tagline": settings.PROJECT_TAGLINE,
        "version": settings.VERSION,
        "docs_url": "/docs",
        "v1_api": f"{settings.API_V1_STR}/health",
        "emergency_hotline": settings.CYBER_HELPLINE_PHONE,
        "mission": "Shift digital privacy from reactive cleanup to proactive intervention."
    }
