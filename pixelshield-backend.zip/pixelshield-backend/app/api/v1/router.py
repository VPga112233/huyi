"""Combined API v1 Router for PixelShield."""
from fastapi import APIRouter
from app.api.v1.endpoints import protect, watch, respond, forensics, health

api_router = APIRouter()

api_router.include_router(health.router, prefix="/health", tags=["Diagnostics & System Health"])
api_router.include_router(protect.router, prefix="/protect", tags=["Layer 01: Protect (Cloaking & Stress Test)"])
api_router.include_router(watch.router, prefix="/watch", tags=["Layer 02: Watch (Fingerprinting & Alerts)"])
api_router.include_router(respond.router, prefix="/respond", tags=["Layer 03: Respond (Vault, Takedowns & SOS)"])
api_router.include_router(forensics.router, prefix="/forensics", tags=["Layer 03: Respond (Forensic Fake Detection)"])
