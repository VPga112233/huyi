"""PixelShield Watch Endpoints (Features 06 & 07).
Handles non-reversible perceptual fingerprinting (Meta PDQ & StopNCII tokens),
opt-in alert subscriptions, and reverse image matching.
"""
from typing import Optional, List
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, HttpUrl, EmailStr

from app.models.base import get_db
from app.models.fingerprint import AlertSubscription, MisuseMatchLog, ShieldedFingerprint
from app.engine.fingerprint import fingerprint_engine, hamming_distance_hex
from app.services.alert_crawler import alert_crawler

router = APIRouter()


class SubscribeRequest(BaseModel):
    pdq_hash: str
    blinded_token: Optional[str] = None
    callback_webhook: Optional[str] = None
    alert_email: Optional[str] = None
    alert_phone: Optional[str] = None
    match_threshold: Optional[int] = 32


@router.post("/fingerprint")
async def generate_perceptual_fingerprints(
    file: UploadFile = File(..., description="Image to generate non-reversible fingerprints for")
):
    """
    Feature 07: Extracts exact-match SHA-256, Meta 256-bit PDQ, pHash, dHash, wHash,
    and StopNCII-style zero-knowledge blinded blocking token.
    """
    img_bytes = await file.read()
    if not img_bytes:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    fingerprints = fingerprint_engine.generate_fingerprints(img_bytes)
    return {
        "status": "SUCCESS",
        "fingerprints": fingerprints,
        "note": "Blinded token can be safely shared with platforms to block reposting without sharing the photo."
    }


@router.post("/subscribe")
def register_alert_subscription(
    req: SubscribeRequest,
    db: Session = Depends(get_db)
):
    """
    Feature 06: Opt-in monitoring. Subscribes blinded token / PDQ hash
    for automated web crawler scanning with webhook/email/SMS alerts.
    """
    if len(req.pdq_hash) != 64:
        raise HTTPException(status_code=400, detail="Invalid PDQ hash format. Expected 64-hex character string.")

    blinded_token = req.blinded_token or fingerprint_engine.generate_fingerprints.__closure__
    from app.core.security import generate_blinded_token
    token = req.blinded_token or generate_blinded_token(req.pdq_hash)

    sub = AlertSubscription(
        blinded_token=token,
        pdq_hash=req.pdq_hash.strip().lower(),
        callback_webhook=str(req.callback_webhook) if req.callback_webhook else None,
        alert_email=req.alert_email,
        alert_phone=req.alert_phone,
        match_threshold=req.match_threshold or 32,
        is_active=True
    )
    db.add(sub)
    db.commit()
    db.refresh(sub)

    return {
        "status": "ACTIVE",
        "subscription_id": sub.id,
        "blinded_token": sub.blinded_token,
        "match_threshold": sub.match_threshold,
        "message": "Opt-in monitoring activated. Privacy crawler will alert configured channels if matches are found."
    }


@router.post("/scan-candidate")
async def scan_public_candidate_image(
    candidate_file: UploadFile = File(..., description="Suspect image discovered online"),
    source_url: str = Form("https://public-web.example/photo.jpg", description="URL where the image was found"),
    platform_name: str = Form("Social Platform", description="Platform name (e.g. Instagram, Telegram)"),
    db: Session = Depends(get_db)
):
    """
    Feature 06: Scans a candidate image against all active subscriptions.
    If PDQ Hamming distance <= threshold, logs a match and fires alerts.
    """
    candidate_bytes = await candidate_file.read()
    if not candidate_bytes:
        raise HTTPException(status_code=400, detail="Candidate image is empty.")

    matches = alert_crawler.scan_image_candidate(
        candidate_image_bytes=candidate_bytes,
        source_url=source_url,
        platform_name=platform_name,
        db=db
    )

    return {
        "status": "SCAN_COMPLETE",
        "matches_count": len(matches),
        "matches": matches,
        "alert_dispatched": len(matches) > 0
    }


@router.get("/matches/{subscription_id}")
def get_subscription_matches(
    subscription_id: int,
    db: Session = Depends(get_db)
):
    """Retrieves discovered match logs for a given subscription ID."""
    sub = db.query(AlertSubscription).filter(AlertSubscription.id == subscription_id).first()
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found.")

    matches = db.query(MisuseMatchLog).filter(MisuseMatchLog.subscription_id == subscription_id).all()
    return {
        "subscription_id": subscription_id,
        "blinded_token": sub.blinded_token,
        "total_matches": len(matches),
        "logs": [
            {
                "id": m.id,
                "platform": m.platform,
                "matched_url": m.matched_url,
                "hamming_distance": m.hamming_distance,
                "discovered_at": m.discovered_at.isoformat(),
                "alert_dispatched": m.alert_dispatched
            } for m in matches
        ]
    }
