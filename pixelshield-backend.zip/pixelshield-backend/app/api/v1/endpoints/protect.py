"""PixelShield Protect Endpoints (Features 01, 02, 03, 04, 05, 12).
Handles adversarial perturbation cloaking, social media stress tests,
zero-knowledge client sync, and empirical threat assessments.
"""
from typing import Optional
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException, Response
from fastapi.responses import JSONResponse
import io

from app.config import settings
from app.engine.cloaker import cloaking_engine
from app.engine.stress_test import simulator
from app.core.limits import get_threat_assessment

router = APIRouter()


@router.post("/cloak")
async def apply_adversarial_cloak(
    file: UploadFile = File(..., description="Target photo to shield"),
    preset: str = Form("high", description="Shield strength: standard, high, or ultra"),
    custom_steps: Optional[int] = Form(None, description="Optional custom PGD optimization steps"),
    format_output: str = Form("json", description="'json' with base64 + metrics, or 'image' for direct PNG binary")
):
    """
    Feature 01 & 02: Injects 60-step PGD/EOT adversarial perturbations
    to disrupt Face Swaps and Latent VAE Generative Fill/Inpainting.
    """
    if preset.lower() not in settings.SHIELD_PRESETS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid preset '{preset}'. Choose from: {list(settings.SHIELD_PRESETS.keys())}"
        )

    image_bytes = await file.read()
    if len(image_bytes) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    try:
        cloaked_bytes, metrics, assessment = cloaking_engine.cloak(
            image_bytes=image_bytes,
            preset=preset,
            custom_steps=custom_steps
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Adversarial cloaking failed: {str(e)}")

    if format_output == "image":
        return Response(content=cloaked_bytes, media_type="image/png")

    import base64
    return {
        "status": "SUCCESS",
        "message": "Adversarial shield applied successfully. Photo is cloaked.",
        "shield_preset": preset,
        "empirical_metrics": metrics,
        "threat_assessment": assessment,
        "cloaked_image_base64": base64.b64encode(cloaked_bytes).decode("ascii"),
        "zero_knowledge_note": "PixelShield server has discarded the unshielded image from memory."
    }


@router.post("/stress-test")
async def run_compression_stress_test(
    original_file: UploadFile = File(..., description="Original unprotected image"),
    cloaked_file: UploadFile = File(..., description="Cloaked image to test")
):
    """
    Feature 03: Live resilience scoring against WhatsApp downsampling,
    Instagram compression, and screenshot cropping pipelines.
    """
    orig_bytes = await original_file.read()
    cloaked_bytes = await cloaked_file.read()

    if not orig_bytes or not cloaked_bytes:
        raise HTTPException(status_code=400, detail="Both original and cloaked files are required.")

    try:
        results = simulator.run_stress_test(orig_bytes, cloaked_bytes)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Stress test simulation failed: {str(e)}")


@router.get("/client-params")
def get_on_device_parameters(preset: str = "high"):
    """
    Feature 04: Zero-Knowledge / 100% On-Device Local Processing.
    Returns ONNX model metadata, JND thresholds, and optimization schedules
    for client-side WASM execution so photos never leave the user's device.
    """
    return cloaking_engine.get_client_parameters(preset=preset)


@router.get("/presets")
def get_shield_presets():
    """
    Feature 12: Adaptive Shield Strength Configuration.
    Returns available presets: Standard, High, Ultra.
    """
    return {
        "available_presets": settings.SHIELD_PRESETS,
        "recommendation": "Use 'high' for everyday social sharing, or 'ultra' for WhatsApp/Telegram profile photos."
    }


@router.get("/threat-assessment")
def get_threat_assessment_details(preset: str = "high"):
    """
    Feature 05: Honest Protection Limits & Threat Assessment.
    Provides transparent boundary disclosures and attack cost analysis.
    """
    return get_threat_assessment(preset_name=preset)
