"""PixelShield Respond Endpoints (Features 08, 09, 11).
Handles Cryptographic Evidence Vault (Section 65B dossiers),
Automated IT Act Takedowns, and Blackmail Emergency SOS Mode.
"""
from typing import Optional, List, Dict, Any
import json
from pathlib import Path
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel

from app.models.base import get_db
from app.models.evidence import EvidenceCase, ChainOfCustodyLog
from app.services.evidence_vault import evidence_vault
from app.services.takedown_builder import takedown_builder
from app.services.emergency_mode import emergency_handler
from app.core.security import verify_tamper_seal
from app.engine.forensics import forensic_engine
from app.engine.fingerprint import fingerprint_engine

router = APIRouter()


class VerifySealRequest(BaseModel):
    payload: Dict[str, Any]
    tamper_seal_signature: str


class InitiateSOSRequest(BaseModel):
    blackmailer_handle: Optional[str] = "Unknown"
    blackmailer_demands: Optional[str] = "Financial / Intimacy extortion"
    trusted_contacts: List[Dict[str, str]] = []


class PreserveChatRequest(BaseModel):
    incident_id: str
    chat_transcript: str


# ==========================================
# FEATURE 08: EVIDENCE VAULT ENDPOINTS
# ==========================================

@router.post("/evidence/seal")
async def seal_evidence_in_vault(
    evidence_file: UploadFile = File(..., description="The non-consensual / deepfake image file"),
    incident_type: str = Form("AI Deepfake / Non-Consensual Imagery"),
    platform_name: str = Form("Instagram / Telegram / Web"),
    platform_url: str = Form("https://target-platform.com/post/123"),
    perpetrator_handle: Optional[str] = Form(None),
    db: Session = Depends(get_db)
):
    """
    Feature 08: Creates a digitally sealed Section 65B forensic dossier
    and cryptographic ZIP package with HMAC-SHA256 tamper seals.
    """
    img_bytes = await evidence_file.read()
    if not img_bytes:
        raise HTTPException(status_code=400, detail="Evidence file cannot be empty.")

    # Run quick forensic check to include in report
    try:
        forensic_results = forensic_engine.analyze(img_bytes)
    except Exception:
        forensic_results = {}

    # Extract perceptual hashes
    try:
        hashes = fingerprint_engine.generate_fingerprints(img_bytes)
    except Exception:
        hashes = {"pdq_hash_256bit": "N/A", "phash_64bit": "N/A", "blinded_blocking_token": "N/A"}

    case_info = {
        "incident_type": incident_type,
        "platform_name": platform_name,
        "platform_url": platform_url,
        "perpetrator_handle": perpetrator_handle or "Unknown",
        "pdq_hash": hashes.get("pdq_hash_256bit"),
        "phash": hashes.get("phash_64bit"),
        "blinded_token": hashes.get("blinded_blocking_token"),
    }

    case_id, zip_path, metadata = evidence_vault.create_evidence_package(
        case_info=case_info,
        image_bytes=img_bytes,
        forensic_results=forensic_results
    )

    # Record in database
    db_case = EvidenceCase(
        case_id=case_id,
        incident_type=incident_type,
        target_name="Complainant",
        platform_url=platform_url,
        perpetrator_handle=perpetrator_handle,
        original_sha256=metadata["sha256"],
        perceptual_pdq=hashes.get("pdq_hash_256bit"),
        perceptual_phash=hashes.get("phash_64bit"),
        tamper_seal_signature=metadata["tamper_seal"],
        section_65b_cert_id=metadata["cert_id"],
        status="SEALED",
        pdf_filename=metadata.get("pdf_filename"),
        zip_filename=metadata.get("zip_filename")
    )
    db.add(db_case)

    # Chain of custody log
    custody_log = ChainOfCustodyLog(
        case_id=case_id,
        action="SEALED",
        performed_by="PixelShield Evidence Enclave",
        details="Generated Section 65B Certificate & Sealed ZIP Package",
        entry_hash=metadata["sha256"]
    )
    db.add(custody_log)
    db.commit()

    return {
        "status": "SEALED",
        "case_id": case_id,
        "section_65b_cert_id": metadata["cert_id"],
        "tamper_seal_hmac": metadata["tamper_seal"],
        "sha256_digest": metadata["sha256"],
        "download_url": f"/api/v1/respond/evidence/{case_id}/download",
        "instructions": "Present this sealed PDF / ZIP to Cyber Police or upload directly to cybercrime.gov.in."
    }


@router.get("/evidence/{case_id}/download")
def download_evidence_package(
    case_id: str,
    file_type: str = "zip",
    db: Session = Depends(get_db)
):
    """Downloads the digitally sealed ZIP evidence archive or Section 65B PDF dossier."""
    case = db.query(EvidenceCase).filter(EvidenceCase.case_id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Evidence case not found.")

    from app.config import settings
    if file_type.lower() == "pdf":
        file_path = settings.VAULT_DIR / case.pdf_filename
        media_type = "application/pdf"
        filename = case.pdf_filename
    else:
        file_path = settings.VAULT_DIR / case.zip_filename
        media_type = "application/zip"
        filename = case.zip_filename

    if not file_path.exists():
        raise HTTPException(status_code=404, detail="Evidence package file not found on server.")

    # Log download access
    custody_log = ChainOfCustodyLog(
        case_id=case_id,
        action="DOWNLOADED",
        performed_by="User Client / Legal Authorized Agent",
        details=f"Downloaded {file_type.upper()} package",
        entry_hash=case.original_sha256
    )
    db.add(custody_log)
    db.commit()

    return FileResponse(path=str(file_path), media_type=media_type, filename=filename)


@router.post("/evidence/verify")
def verify_evidence_seal(req: VerifySealRequest):
    """Verifies that an evidence record payload has not been modified after sealing."""
    is_valid = verify_tamper_seal(req.payload, req.tamper_seal_signature)
    return {
        "is_tamper_proof_valid": is_valid,
        "verification_status": "AUTHENTIC_UNMODIFIED" if is_valid else "TAMPERING_DETECTED",
        "message": "Seal verified against PixelShield cryptographic signing enclave." if is_valid else "Hash mismatch! The evidence payload has been altered."
    }


# ==========================================
# FEATURE 09: LEGAL TAKEDOWNS & CYBERCRIME
# ==========================================

@router.post("/takedown/generate")
def generate_legal_takedown(
    platform: str = Form("Instagram", description="Target platform (Instagram, X, Telegram, etc.)"),
    platform_url: str = Form("https://instagram.com/p/xyz", description="Infringing post link"),
    perpetrator_handle: Optional[str] = Form("target_account"),
    case_id: Optional[str] = Form(None, description="Optional Vault Case ID for cross-referencing"),
    sha256_hash: Optional[str] = Form(None)
):
    """
    Feature 09: Generates legally enforceable takedown notice under IT Act 2000
    Sec 66E/67A & Rule 3(2)(b) (24-hr deadline) + cybercrime.gov.in portal schema.
    """
    case_data = {
        "platform_name": platform,
        "platform_url": platform_url,
        "perpetrator_handle": perpetrator_handle or "Unknown",
        "case_id": case_id or "PS-CASE-PENDING",
        "sha256": sha256_hash or "N/A",
    }
    notice_bundle = takedown_builder.generate_platform_notice(
        platform=platform,
        case_data=case_data
    )
    return notice_bundle


# ==========================================
# FEATURE 11: EMERGENCY SOS & SEXTORTION
# ==========================================

@router.get("/sos/guidance")
def get_sos_guidance(lang: str = "en"):
    """
    Feature 11: Returns emergency 'Do Not Pay' protocol directives
    and direct hotlines (1930 National Cyber Helpline, NCW 7827170170).
    """
    return emergency_handler.get_crisis_guidance(lang=lang)


@router.post("/sos/initiate")
def initiate_emergency_sos(
    req: InitiateSOSRequest,
    db: Session = Depends(get_db)
):
    """
    Feature 11: Starts the crisis state machine, locks down instructions,
    and alerts designated trusted contacts via SMS.
    """
    return emergency_handler.initiate_sos(
        blackmailer_handle=req.blackmailer_handle,
        blackmailer_demands=req.blackmailer_demands,
        trusted_contacts=req.trusted_contacts,
        db=db
    )


@router.post("/sos/preserve-chat")
async def preserve_extortion_chat(
    incident_id: str = Form(...),
    chat_transcript: str = Form(..., description="Exported chat text or threat messages"),
    screenshot_file: Optional[UploadFile] = File(None, description="Optional screenshot of threats/payment handles"),
    db: Session = Depends(get_db)
):
    """
    Feature 11: Automatically seals threat chat logs and extortionist UPI/handles
    into the evidence vault with court-admissible Section 65B certification.
    """
    screenshot_bytes = None
    if screenshot_file:
        screenshot_bytes = await screenshot_file.read()

    try:
        report = emergency_handler.preserve_chat_evidence(
            incident_id=incident_id,
            chat_transcript=chat_transcript,
            screenshot_bytes=screenshot_bytes,
            db=db
        )
        return report
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/sos/escalate/{incident_id}")
def escalate_sos_to_authorities(
    incident_id: str,
    db: Session = Depends(get_db)
):
    """
    Feature 11: Prepares police filing checklist and escalates state to LAW_ENFORCEMENT_READY.
    """
    try:
        report = emergency_handler.escalate_to_law_enforcement(incident_id=incident_id, db=db)
        return report
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
