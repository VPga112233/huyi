"""PixelShield Health & System Diagnostics Endpoint."""
from fastapi import APIRouter
import torch
from app.config import settings
from app.core.i18n import get_supported_languages

router = APIRouter()


@router.get("/")
def health_check():
    """Returns platform diagnostic status and defense layer availability."""
    return {
        "platform": settings.PROJECT_NAME,
        "tagline": settings.PROJECT_TAGLINE,
        "version": settings.VERSION,
        "status": "OPERATIONAL",
        "device": "cuda" if torch.cuda.is_available() else "cpu",
        "layers": {
            "layer_01_protect": {
                "status": "ACTIVE",
                "features": ["01_adversarial_cloaking", "02_dual_ai_shield", "03_stress_test_simulator", "04_zk_on_device_sync", "05_threat_assessment"]
            },
            "layer_02_watch": {
                "status": "ACTIVE",
                "features": ["06_opt_in_misuse_alerts", "07_non_reversible_pdq_fingerprinting"]
            },
            "layer_03_respond": {
                "status": "ACTIVE",
                "features": ["08_cryptographic_evidence_vault", "09_legal_takedown_bundler", "10_fake_forensics_engine", "11_blackmail_emergency_sos"]
            },
            "layer_04_reach": {
                "status": "ACTIVE",
                "features": ["12_adaptive_shield_strengths", "13_multilingual_localization"]
            }
        },
        "supported_locales": get_supported_languages(),
        "emergency_hotline": settings.CYBER_HELPLINE_PHONE
    }
