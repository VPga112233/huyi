"""PixelShield Configuration Module.
Defines system settings, adversarial ML parameters, forensic constants,
and emergency crisis contacts.
"""
from typing import List, Dict, Any
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    # Application Info
    PROJECT_NAME: str = "PixelShield"
    PROJECT_TAGLINE: str = "Protect Before You Post"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    ENVIRONMENT: str = "production"
    DEBUG: bool = False

    # Security & Cryptography
    SECRET_KEY: str = "pixelshield-inviolable-secret-key-32b-min-entropy-2026"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    HMAC_SALT_HASH: str = "pixelshield-zk-fingerprint-salt-v1"

    # CORS
    ALLOWED_ORIGINS: List[str] = ["*"]

    # Storage Paths
    BASE_DIR: Path = BASE_DIR
    STORAGE_DIR: Path = BASE_DIR / "storage"
    VAULT_DIR: Path = BASE_DIR / "storage" / "vault"
    TEMP_DIR: Path = BASE_DIR / "storage" / "temp"

    # Database
    DATABASE_URL: str = f"sqlite:///{BASE_DIR}/pixelshield.db"

    # Feature 01 & 02: Adversarial Cloaking & Loss Constants
    DEFAULT_PGD_STEPS: int = 60
    STEP_SIZE_ALPHA: float = 1.5 / 255.0
    LAMBDA_BIO: float = 1.0     # ArcFace / Biometric Disruption Weight
    LAMBDA_VAE: float = 0.8     # Latent VAE / Generative Fill Entropy Disruption Weight
    LAMBDA_JND: float = 0.2     # Just Noticeable Difference Perceptual Regularizer

    # EOT (Expectation Over Transformation) Ranges
    EOT_NOISE_STD_MIN: float = 0.01
    EOT_NOISE_STD_MAX: float = 0.05
    EOT_JPEG_Q_MIN: int = 65
    EOT_JPEG_Q_MAX: int = 85
    EOT_SCALE_MIN: float = 0.85
    EOT_SCALE_MAX: float = 1.15
    EOT_COLOR_JITTER: float = 0.04

    # Feature 12: Adaptive Shield Strength Presets
    SHIELD_PRESETS: Dict[str, Dict[str, Any]] = {
        "standard": {
            "name": "Standard Shield",
            "description": "Fast imperceptible protection. Defends against automated scrapers, web crawlers, and basic face swap apps.",
            "epsilon": 4.0 / 255.0,
            "steps": 40,
            "eot_samples": 2,
            "target_psnr_db": 42.0,
            "target_ssim": 0.985,
            "resilience_rating": "7.5/10",
        },
        "high": {
            "name": "High Shield (Recommended)",
            "description": "Balanced high-entropy defense. Defends against Stable Diffusion inpainting, deepfake models, and social media compression.",
            "epsilon": 8.0 / 255.0,
            "steps": 60,
            "eot_samples": 4,
            "target_psnr_db": 38.0,
            "target_ssim": 0.965,
            "resilience_rating": "8.8/10",
        },
        "ultra": {
            "name": "Ultra / WhatsApp-Proof Shield",
            "description": "Maximum resilience defense. Survives aggressive WhatsApp downsampling, Instagram recompression, and screenshot crops.",
            "epsilon": 12.0 / 255.0,
            "steps": 80,
            "eot_samples": 6,
            "target_psnr_db": 34.5,
            "target_ssim": 0.940,
            "resilience_rating": "9.6/10",
        },
    }

    # Feature 07: Perceptual Fingerprint Matching Thresholds
    PDQ_HAMMING_THRESHOLD: int = 32      # Out of 256 bits (<=32 considered strong match)
    PHASH_HAMMING_THRESHOLD: int = 10    # Out of 64 bits (<=10 considered visual duplicate)
    DHASH_HAMMING_THRESHOLD: int = 10
    WHASH_HAMMING_THRESHOLD: int = 10

    # Feature 09: Legal Notice & Indian IT Act Statutes
    LEGAL_JURISDICTION: str = "Republic of India"
    STATUTES_REFERENCED: List[str] = [
        "Section 66E, Information Technology Act, 2000 (Violation of Privacy / Capturing non-consensual images)",
        "Section 67A, Information Technology Act, 2000 (Transmitting sexually explicit material in electronic form)",
        "Section 354D, Indian Penal Code / Section 78 Bharatiya Nyaya Sanhita, 2023 (Cyber Stalking)",
        "Section 509, Indian Penal Code / Section 79 Bharatiya Nyaya Sanhita, 2023 (Insult to modesty of woman)",
        "Section 79(3)(b), Information Technology Act, 2000 (Intermediary liability & mandatory takedown within 24 hours)",
        "Rule 3(2)(b), Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021",
    ]

    # Feature 11: Emergency Helplines
    CYBER_HELPLINE_PHONE: str = "1930"
    CYBER_HELPLINE_NAME: str = "National Cyber Crime Helpline (India)"
    CYBER_PORTAL_URL: str = "https://cybercrime.gov.in"
    NCW_HELPLINE_PHONE: str = "7827170170"
    NCW_HELPLINE_NAME: str = "National Commission for Women (NCW) 24x7 Helpline"
    CHILDLINE_PHONE: str = "1098"
    EMERGENCY_POLICE_PHONE: str = "112"

    model_config = SettingsConfigDict(case_sensitive=True, env_file=".env", extra="ignore")


settings = Settings()

# Ensure critical directories exist
settings.STORAGE_DIR.mkdir(parents=True, exist_ok=True)
settings.VAULT_DIR.mkdir(parents=True, exist_ok=True)
settings.TEMP_DIR.mkdir(parents=True, exist_ok=True)
