"""Database schemas for Blackmail & Sextortion Emergency SOS Incidents."""
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text
from app.models.base import Base


class EmergencyIncident(Base):
    __tablename__ = "emergency_incidents"

    incident_id = Column(String(64), primary_key=True, index=True)
    current_state = Column(String(64), default="INITIATED")  # INITIATED, CONTACTS_ALERTED, EVIDENCE_LOCKED, RESOLVED
    is_blackmail = Column(Boolean, default=True)
    blackmailer_handle = Column(String(128), nullable=True)
    blackmailer_demands = Column(Text, nullable=True)
    contacts_notified = Column(Text, nullable=True)          # JSON list of trusted contacts
    helpline_1930_referred = Column(Boolean, default=True)
    ncw_referred = Column(Boolean, default=True)
    chat_logs_preserved_count = Column(Integer, default=0)
    vault_case_id = Column(String(64), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
