"""Database schemas for perceptual fingerprints and opt-in watch alerts."""
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.models.base import Base


class ShieldedFingerprint(Base):
    __tablename__ = "shielded_fingerprints"

    id = Column(Integer, primary_key=True, index=True)
    file_sha256 = Column(String(64), index=True, nullable=False)
    pdq_hash = Column(String(64), index=True, nullable=False)       # 256-bit hex
    phash = Column(String(32), index=True, nullable=False)          # 64-bit hex
    dhash = Column(String(32), nullable=True)
    whash = Column(String(32), nullable=True)
    blinded_token = Column(String(64), index=True, nullable=False)  # Zero-knowledge StopNCII token
    shield_preset = Column(String(32), default="high")
    user_tag = Column(String(64), nullable=True)                    # Pseudonym
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class AlertSubscription(Base):
    __tablename__ = "alert_subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    blinded_token = Column(String(64), index=True, nullable=False)
    pdq_hash = Column(String(64), nullable=False)
    callback_webhook = Column(String(512), nullable=True)
    alert_email = Column(String(256), nullable=True)
    alert_phone = Column(String(32), nullable=True)
    match_threshold = Column(Integer, default=32)                   # PDQ hamming threshold
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    matches = relationship("MisuseMatchLog", back_populates="subscription", cascade="all, delete-orphan")


class MisuseMatchLog(Base):
    __tablename__ = "misuse_match_logs"

    id = Column(Integer, primary_key=True, index=True)
    subscription_id = Column(Integer, ForeignKey("alert_subscriptions.id"))
    matched_url = Column(String(1024), nullable=False)
    platform = Column(String(64), nullable=False)
    hamming_distance = Column(Integer, nullable=False)
    discovered_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    alert_dispatched = Column(Boolean, default=False)

    subscription = relationship("AlertSubscription", back_populates="matches")
