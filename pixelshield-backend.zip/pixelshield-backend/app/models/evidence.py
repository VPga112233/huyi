"""Database schemas for Evidence Vault cases and chain-of-custody audit logs."""
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from app.models.base import Base


class EvidenceCase(Base):
    __tablename__ = "evidence_cases"

    case_id = Column(String(64), primary_key=True, index=True)      # e.g. PS-VAULT-...
    incident_type = Column(String(64), nullable=False)               # Deepfake, Non-Consensual Imagery, etc.
    target_name = Column(String(128), default="Victim/Complainant")
    platform_url = Column(String(1024), nullable=True)
    perpetrator_handle = Column(String(128), nullable=True)
    original_sha256 = Column(String(64), nullable=False)
    perceptual_pdq = Column(String(64), nullable=True)
    perceptual_phash = Column(String(32), nullable=True)
    tamper_seal_signature = Column(String(128), nullable=False)
    section_65b_cert_id = Column(String(64), nullable=False)
    status = Column(String(32), default="SEALED")
    pdf_filename = Column(String(256), nullable=True)
    zip_filename = Column(String(256), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    custody_logs = relationship("ChainOfCustodyLog", back_populates="case", cascade="all, delete-orphan")


class ChainOfCustodyLog(Base):
    __tablename__ = "chain_of_custody_logs"

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(String(64), ForeignKey("evidence_cases.case_id"))
    action = Column(String(64), nullable=False)                      # CREATED, SEALED, DOWNLOADED, VERIFIED
    performed_by = Column(String(128), default="PixelShield Forensic Engine")
    details = Column(Text, nullable=True)
    entry_hash = Column(String(64), nullable=False)
    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    case = relationship("EvidenceCase", back_populates="custody_logs")
