# 🛡️ PixelShield ("Photo Shield: Protect Before You Post")

> **Proactive AI Security, Anti-Deepfake Cloaking & Emergency Response Engine**  
> *Shifting digital privacy from reactive cleanup to proactive intervention.*

PixelShield stops harm at Step 1 (before upload) by injecting imperceptible adversarial cloaks and non-reversible perceptual fingerprints into photos, while providing continuous monitoring, court-admissible forensic evidence dossiers, automated legal takedowns, and crisis emergency response for at-risk users.

---

## 🎯 4 Defense Layers · 13 Essential Features

### Layer 01: PROTECT (Proactive Image Shielding)
1. **Adversarial Perturbation Cloaking Engine**: 60-step iterative PGD with Expectation Over Transformation (EOT), disrupting Face Swaps (spatial dissimilarity), AI inpainting/nudification (latent VAE patch entropy), and model fine-tuning (texture poisoning).
2. **Dual AI Shield Architecture**: Joint optimization targeting biometric identity extractors (ArcFace/RetinaFace) and Latent Diffusion VAE receptive fields.
3. **Social Media Stress Test Simulator**: Emulates real platform re-encoding pipelines (WhatsApp downsampling to 1600px with 4:2:0 subsampling, Instagram feed compression at Q=78, and screenshot cropping) with live resilience ratings (e.g. `8.8/10`).
4. **Zero-Knowledge / 100% On-Device Local Processing**: Parameter and model configuration endpoint (`/api/v1/protect/client-params`) enabling browser WASM/WebGPU client execution—unshielded photos never touch external servers.
5. **Honest Protection Limits & Threat Assessment**: Transparent boundary disclosures, empirical metrics (PSNR, SSIM, $L_\infty$ norm), and adversary compute cost modeling.

### Layer 02: WATCH (Continuous Privacy Monitoring)
6. **Opt-In Misuse Webhook & Alert Engine**: Privacy-preserving crawler matching against public web/social channels with automated Webhook, SMS, Email, and WhatsApp alerts.
7. **Non-Reversible Fingerprint Blocking Engine**: StopNCII-style dual perceptual hashing combining exact cryptographic SHA-256, Meta/Facebook 256-bit PDQ, pHash, dHash, wHash, and HMAC-blinded platform tokens.

### Layer 03: RESPOND (Forensic & Legal Emergency Response)
8. **One-Tap Cryptographic Evidence Vault**: Generates court-admissible electronic evidence packages with ISO timestamps, SHA-256 tamper seals, and formal Section 65B Indian Evidence Act / Section 63 BSA 2023 certificates.
9. **Automated Legal Takedown & Cybercrime Bundler**: Auto-populates 24-hour statutory legal notices under Rule 3(2)(b) and Sections 66E/67A of the IT Act 2000 for Instagram, X, Telegram, and India's National Cyber Crime Portal (`cybercrime.gov.in`).
10. **"Is This Picture Fake?" Forensic Analysis Engine**: Multi-modal fake detection combining dual-grid Error Level Analysis (ELA), 2D Fast Fourier Transform (FFT) high-frequency synthetic grid analysis, and facial perimeter gradient seam detection with trauma-informed plain-language explanations.
11. **Blackmail & Sextortion Emergency SOS Mode**: Crisis workflow state machine with "Do Not Pay" psychological stabilization, automated threat chat log preservation, trusted contact SOS alerts, and direct integration with the **1930 National Cyber Crime Helpline** and NCW resources.

### Layer 04: REACH (Accessibility & Localization)
12. **Adaptive Shield Strength Configuration**: Dynamic presets (`standard`, `high`, `ultra/whatsapp-proof`) balancing perceptual invisibility (PSNR > 38 dB) and downsampling resilience.
13. **Multilingual Localization Engine**: Native i18n support for English (`en`), Hindi (`hi`), Tamil (`ta`), Bengali (`bn`), Telugu (`te`), and Marathi (`mr`) across all reports, legal notices, and crisis alerts.

---

## 📐 Mathematical Formulation

### 1. Dual Defense Loss Function
$$\mathcal{L}_{\text{total}} = \lambda_{\text{bio}} \mathcal{L}_{\text{ArcFace}}(\mathbf{x} + \boldsymbol{\delta}) + \lambda_{\text{vae}} \mathcal{L}_{\text{VAE}}(\mathbf{x} + \boldsymbol{\delta}) + \lambda_{\text{jnd}} \|\boldsymbol{\delta}\|_{\infty}$$

- **Biometric Disruption ($\mathcal{L}_{\text{ArcFace}}$)**: Minimizes cosine similarity between the identity embedding $\mathbf{f}(\mathbf{x})$ and the perturbed face $\mathbf{f}(\mathbf{x} + \boldsymbol{\delta})$, driving face recognition distance beyond recognition thresholds ($d_{\cos} > 0.65$).
- **Latent VAE Disruption ($\mathcal{L}_{\text{VAE}}$)**: Maximizes latent variance and entropy across $8\times 8$ convolutional receptive fields, causing latent diffusion inpainting models to collapse into noisy artifacts or extreme blur.
- **Just Noticeable Difference (JND) Masking**: Modulates perturbation budget $\epsilon(i, j)$ using local spatial variance:
  $$\text{JND}(i, j) = 0.4 + 1.2 \cdot \frac{\sigma_{\text{local}}(i, j)}{\max(\sigma_{\text{local}}) + 10^{-6}}$$
  High-texture areas absorb higher noise while smooth skin and flat backgrounds remain clean.

---

## 📂 Project Architecture

```
pixelshield-backend/
├── app/
│   ├── main.py                  # FastAPI application & security middleware
│   ├── config.py                # Pydantic v2 settings & defense presets
│   ├── core/
│   │   ├── security.py          # HMAC tamper seals, blinded tokens, SHA-256
│   │   ├── i18n.py              # Multi-language translation engine (HI, TA, BN, EN)
│   │   └── limits.py            # Rate limiting, PSNR/SSIM, honest threat boundary rules
│   ├── engine/
│   │   ├── cloaker.py           # Features 1 & 2: Adversarial cloaking (PGD/EOT)
│   │   ├── stress_test.py       # Feature 3: WhatsApp/Instagram compression simulator
│   │   ├── fingerprint.py       # Feature 7: Meta PDQ & cryptographic perceptual hashing
│   │   └── forensics.py         # Feature 10: ELA, 2D FFT, facial boundary blend detector
│   ├── services/
│   │   ├── evidence_vault.py    # Feature 8: Section 65B certified PDF & ZIP packages
│   │   ├── takedown_builder.py  # Feature 9: Indian IT Act & platform takedown schemas
│   │   ├── alert_crawler.py     # Feature 6: Opt-in reverse search & misuse alerts
│   │   └── emergency_mode.py    # Feature 11: Blackmail crisis handler & SOS state machine
│   ├── api/
│   │   └── v1/
│   │       ├── router.py        # Combined v1 API router
│   │       └── endpoints/
│   │           ├── protect.py   # Cloaking, stress tests, local parameter sync
│   │           ├── watch.py     # Hash registration, opt-in alerts, matcher
│   │           ├── respond.py   # Evidence seal, takedown templates, SOS trigger
│   │           ├── forensics.py # 'Is this picture fake?' endpoint
│   │           └── health.py    # Diagnostics and defense layer status
│   ├── models/                  # Database models
│   │   ├── base.py              # Engine and session initialization
│   │   ├── fingerprint.py       # Perceptual hashes and alert subscriptions
│   │   ├── evidence.py          # Evidence cases and chain-of-custody audit logs
│   │   └── emergency.py         # Emergency incident states
│   └── locales/                 # Feature 13: i18n dictionaries
│       ├── en.json              # English
│       ├── hi.json              # Hindi (हिन्दी)
│       ├── ta.json              # Tamil (தமிழ்)
│       └── bn.json              # Bengali (বাংলা)
├── tests/
│   ├── test_cloaker.py
│   ├── test_stress_test.py
│   ├── test_fingerprints.py
│   └── test_evidence_vault.py
├── pytest.ini
├── requirements.txt
├── Dockerfile
└── README.md
```

---

## 🚀 Quickstart Guide

### 1. Prerequisites
- Python 3.11+
- Git

### 2. Local Setup
```bash
# Clone and enter directory
cd pixelshield-backend

# Create virtual environment
python -m venv .venv

# Activate virtual environment
# Windows:
.\.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

# Install dependencies (CPU PyTorch + OpenCV + ReportLab)
pip install -r requirements.txt --extra-index-url https://download.pytorch.org/whl/cpu

# Run test suite
pytest -v
```

### 3. Launch Development Server
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
- Interactive Swagger UI: `http://localhost:8000/docs`
- Redoc UI: `http://localhost:8000/redoc`
- Health Endpoint: `http://localhost:8000/api/v1/health/`

---

## 🐳 Docker Deployment

```bash
# Build Docker image
docker build -t pixelshield-backend:1.0 .

# Run container
docker run -d -p 8000:8000 --name pixelshield pixelshield-backend:1.0

# Verify health
curl http://localhost:8000/api/v1/health/
```

---

## 📡 Core API Reference & Examples

### 1. Adversarial Cloaking (`POST /api/v1/protect/cloak`)
Injects 60-step PGD/EOT adversarial perturbations.
```bash
curl -X POST "http://localhost:8000/api/v1/protect/cloak" \
  -F "file=@photo.jpg" \
  -F "preset=high" \
  -F "format_output=json"
```

### 2. Social Media Stress Test (`POST /api/v1/protect/stress-test`)
Tests perturbation resilience against WhatsApp, Instagram, and Screenshot downsampling.
```bash
curl -X POST "http://localhost:8000/api/v1/protect/stress-test" \
  -F "original_file=@original.jpg" \
  -F "cloaked_file=@cloaked.png"
```

### 3. Non-Reversible Fingerprint Extraction (`POST /api/v1/watch/fingerprint`)
Generates Meta 256-bit PDQ, pHash, dHash, and StopNCII blinded token.
```bash
curl -X POST "http://localhost:8000/api/v1/watch/fingerprint" \
  -F "file=@photo.jpg"
```

### 4. Create Cryptographic Evidence Vault Package (`POST /api/v1/respond/evidence/seal`)
Generates Section 65B certified PDF dossier and tamper-sealed ZIP package.
```bash
curl -X POST "http://localhost:8000/api/v1/respond/evidence/seal" \
  -F "evidence_file=@deepfake_screenshot.png" \
  -F "incident_type=AI Deepfake Impersonation" \
  -F "platform_name=Instagram" \
  -F "platform_url=https://instagram.com/p/example" \
  -F "perpetrator_handle=@stalker_user"
```

### 5. Automated 24-Hour Legal Takedown (`POST /api/v1/respond/takedown/generate`)
Generates statutory cease-and-desist under IT Act Rule 3(2)(b) and Sections 66E/67A.
```bash
curl -X POST "http://localhost:8000/api/v1/respond/takedown/generate" \
  -F "platform=Instagram" \
  -F "platform_url=https://instagram.com/p/example" \
  -F "perpetrator_handle=@offender"
```

### 6. Emergency Blackmail Crisis SOS (`POST /api/v1/respond/sos/initiate`)
```bash
curl -X POST "http://localhost:8000/api/v1/respond/sos/initiate" \
  -H "Content-Type: application/json" \
  -d '{
    "blackmailer_handle": "@extortionist",
    "blackmailer_demands": "Demanding ₹50,000 within 2 hours",
    "trusted_contacts": [{"name": "Sister", "phone": "+919876543210"}]
  }'
```

### 7. "Is This Picture Fake?" Forensic Engine (`POST /api/v1/forensics/analyze`)
```bash
curl -X POST "http://localhost:8000/api/v1/forensics/analyze" \
  -F "file=@suspect_photo.jpg"
```

---

## 🛡️ Statutory Legal Framework & Emergency Helplines

| Provision | Statutory Authority | Legal Mandate / Hotline |
|---|---|---|
| **Section 66E, IT Act 2000** | Ministry of Electronics & IT (MeitY) | Privacy violation & non-consensual capture of intimate images |
| **Section 67A, IT Act 2000** | Government of India | Publishing/transmitting sexually explicit electronic content |
| **Rule 3(2)(b), IT Rules 2021** | Intermediary Guidelines | **Mandatory 24-hour takedown** by platforms upon receipt of notice |
| **Section 65B Indian Evidence Act** | High Courts & Supreme Court of India | Prescribed electronic evidence certificate of admissibility |
| **National Cybercrime Helpline** | Ministry of Home Affairs (MHA) | **1930** (Toll-Free, 24x7) |
| **National Portal** | MHA Cyber Crime Cell | [cybercrime.gov.in](https://cybercrime.gov.in) |
| **NCW Women Helpline** | National Commission for Women | **7827170170** (24x7) |

---

## 🔒 Zero-Knowledge Security Architecture

- **No Raw Image Storage**: The PixelShield server operates on a strict zero-retention policy. Unshielded images are held only in volatile memory during the cloaking optimization loop and immediately discarded.
- **Client-Side Execution Protocol**: Mobile and web clients can retrieve the optimization parameters via `/api/v1/protect/client-params` and execute the cloaker locally via WebAssembly / ONNX Runtime.
- **Blinded Tokens**: Platform blocking operates entirely through HMAC-SHA256 blinded hashes—third-party platforms never receive original images or reversible identity embeddings.

---

## 📄 License & Attribution
Developed for the **PixelShield** early defense platform. Licensed under the MIT License.
