"""End-to-End API Router & Endpoint Integration Tests."""
import io
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from app.main import app

client = TestClient(app)


def get_test_png():
    img = Image.new("RGB", (128, 128), color=(140, 160, 180))
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def test_root_and_health():
    resp = client.get("/")
    assert resp.status_code == 200
    assert resp.json()["platform"] == "PixelShield"

    resp_h = client.get("/api/v1/health/")
    assert resp_h.status_code == 200
    assert resp_h.json()["status"] == "OPERATIONAL"
    assert "layer_01_protect" in resp_h.json()["layers"]


def test_protect_client_params_and_presets():
    res_p = client.get("/api/v1/protect/client-params?preset=high")
    assert res_p.status_code == 200
    assert res_p.json()["preset"] == "high"

    res_pre = client.get("/api/v1/protect/presets")
    assert res_pre.status_code == 200
    assert "ultra" in res_pre.json()["available_presets"]


def test_watch_fingerprint_endpoint():
    png_bytes = get_test_png()
    resp = client.post(
        "/api/v1/watch/fingerprint",
        files={"file": ("test.png", png_bytes, "image/png")}
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "SUCCESS"
    assert len(data["fingerprints"]["pdq_hash_256bit"]) == 64
    assert len(data["fingerprints"]["exact_sha256"]) == 64


def test_respond_takedown_endpoint():
    resp = client.post(
        "/api/v1/respond/takedown/generate",
        data={
            "platform": "Instagram",
            "platform_url": "https://instagram.com/p/test12345",
            "perpetrator_handle": "@abuser_handle"
        }
    )
    assert resp.status_code == 200
    data = resp.json()
    assert "24 Hours" in data["statutory_deadline"]
    assert "Section 66E" in data["notice_text"]


def test_respond_sos_guidance_and_initiate():
    resp_g = client.get("/api/v1/respond/sos/guidance?lang=en")
    assert resp_g.status_code == 200
    assert len(resp_g.json()["critical_rules"]) == 3

    resp_i = client.post(
        "/api/v1/respond/sos/initiate",
        json={
            "blackmailer_handle": "@blackmailer_target",
            "blackmailer_demands": "Pay 1000 USD",
            "trusted_contacts": [{"name": "Dad", "phone": "+919999999999"}]
        }
    )
    assert resp_i.status_code == 200
    data = resp_i.json()
    assert data["status"] == "CONTACTS_ALERTED"
    assert "incident_id" in data


def test_forensics_endpoint():
    png_bytes = get_test_png()
    resp = client.post(
        "/api/v1/forensics/analyze",
        files={"file": ("suspect.png", png_bytes, "image/png")}
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "SUCCESS"
    assert "synthetic_confidence_score" in data["results"]
