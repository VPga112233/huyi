"""Tests for Feature 08, 09, 10, 11: Evidence Vault, Legal Notices, Forensics & SOS."""
import io
import os
import zipfile
import pytest
import numpy as np
from PIL import Image

from app.services.evidence_vault import evidence_vault
from app.services.takedown_builder import takedown_builder
from app.engine.forensics import forensic_engine
from app.core.security import verify_tamper_seal, create_tamper_seal


def create_mock_evidence_image():
    arr = np.random.randint(100, 200, (256, 256, 3), dtype=np.uint8)
    img = Image.fromarray(arr)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def test_dossier_pdf_generation():
    evidence_data = {
        "case_id": "PS-VAULT-TEST-1234",
        "cert_id": "CERT-65B-TEST",
        "incident_type": "AI Deepfake Impersonation",
        "platform_name": "Instagram",
        "platform_url": "https://instagram.com/p/test123",
        "sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
        "pdq_hash": "a" * 64,
        "phash": "b" * 16,
        "blinded_token": "c" * 64,
        "tamper_seal": "d" * 64,
    }

    pdf_bytes = evidence_vault.generate_dossier_pdf(evidence_data)
    assert len(pdf_bytes) > 0
    assert pdf_bytes.startswith(b"%PDF")


def test_create_evidence_package_zip():
    img_bytes = create_mock_evidence_image()
    case_info = {
        "incident_type": "Non-Consensual Face Morphing",
        "platform_name": "Telegram Channel",
        "platform_url": "https://t.me/test_leak_channel",
        "perpetrator_handle": "@cyber_offender",
        "pdq_hash": "1" * 64,
        "phash": "2" * 16,
        "blinded_token": "3" * 64,
    }

    case_id, zip_path, meta = evidence_vault.create_evidence_package(
        case_info=case_info,
        image_bytes=img_bytes
    )

    assert os.path.exists(zip_path)
    assert zipfile.is_zipfile(zip_path)

    with zipfile.ZipFile(zip_path, "r") as z:
        filenames = z.namelist()
        assert "forensic_dossier.pdf" in filenames
        assert "chain_of_custody_manifest.json" in filenames
        assert "tamper_seal.sig" in filenames
        assert "incident_summary.txt" in filenames


def test_tamper_seal_integrity():
    payload = {"case_id": "CASE-101", "victim": "User", "hash": "abc"}
    _, sig = create_tamper_seal(payload)

    # Legitimate payload verification
    assert verify_tamper_seal(payload, sig) is True

    # Tampered payload verification
    tampered_payload = {"case_id": "CASE-101", "victim": "User", "hash": "MODIFIED"}
    assert verify_tamper_seal(tampered_payload, sig) is False


def test_legal_takedown_builder():
    case_data = {
        "platform_name": "Instagram",
        "platform_url": "https://instagram.com/reel/xyz",
        "perpetrator_handle": "@stalker_account",
        "case_id": "PS-CASE-456",
        "sha256": "fe" * 32,
    }

    notice = takedown_builder.generate_platform_notice("Instagram", case_data)
    assert "Section 66E" in notice["notice_text"]
    assert "Rule 3(2)(b)" in notice["notice_text"]
    assert "24 Hours" in notice["statutory_deadline"]
    assert "cybercrime_portal_ready" in notice
    portal_data = notice["cybercrime_portal_ready"]
    assert portal_data["portal"] == "https://cybercrime.gov.in"


def test_forensic_analysis_engine():
    img_bytes = create_mock_evidence_image()
    results = forensic_engine.analyze(img_bytes)

    assert "is_likely_ai_generated" in results
    assert "synthetic_confidence_score" in results
    assert "forensic_streams" in results
    assert "error_level_analysis" in results["forensic_streams"]
    assert "fft_frequency_analysis" in results["forensic_streams"]
    assert "facial_boundary_detection" in results["forensic_streams"]
    assert "plain_language_summary" in results
