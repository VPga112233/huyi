"""Tests for Feature 07: Non-Reversible Perceptual Fingerprints."""
import io
import pytest
import numpy as np
from PIL import Image

from app.engine.fingerprint import (
    compute_pdq_hash,
    hamming_distance_hex,
    fingerprint_engine
)
from app.core.security import generate_blinded_token


def create_solid_image(color=(120, 150, 180), size=(200, 200)):
    # Create an image with gradient patterns for stable perceptual hashing
    y, x = np.mgrid[0:size[1], 0:size[0]]
    r = (x * 255 // size[0]).astype(np.uint8)
    g = (y * 255 // size[1]).astype(np.uint8)
    b = ((x + y) * 128 // (size[0] + size[1])).astype(np.uint8)
    arr = np.stack([r, g, b], axis=-1)
    img = Image.fromarray(arr)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue(), img


def test_pdq_hash_length_and_determinism():
    img_bytes, img = create_solid_image()
    pdq1 = compute_pdq_hash(img)
    pdq2 = compute_pdq_hash(img)

    assert len(pdq1) == 64  # 256 bits = 64 hex characters
    assert pdq1 == pdq2
    assert int(pdq1, 16) >= 0


def test_hamming_distance_zero_for_identical():
    hex_str = "a1b2c3d4e5f60718293a4b5c6d7e8f90a1b2c3d4e5f60718293a4b5c6d7e8f90"
    dist = hamming_distance_hex(hex_str, hex_str)
    assert dist == 0


def test_hamming_distance_different():
    hex_a = "0000000000000000000000000000000000000000000000000000000000000000"
    hex_b = "000000000000000000000000000000000000000000000000000000000000000f"
    dist = hamming_distance_hex(hex_a, hex_b)
    assert dist == 4  # 0xf has 4 set bits


def test_fingerprint_bundle_generation():
    img_bytes, _ = create_solid_image()
    bundle = fingerprint_engine.generate_fingerprints(img_bytes)

    assert "exact_sha256" in bundle
    assert "pdq_hash_256bit" in bundle
    assert "phash_64bit" in bundle
    assert "blinded_blocking_token" in bundle
    assert len(bundle["exact_sha256"]) == 64
    assert len(bundle["pdq_hash_256bit"]) == 64
    assert len(bundle["blinded_blocking_token"]) == 64


def test_fingerprint_matching_near_identical():
    # Create an image with textured sinusoidal patterns typical of natural photos
    arr = np.zeros((200, 200, 3), dtype=np.uint8)
    for i in range(200):
        for j in range(200):
            arr[i, j, 0] = int(128 + 127 * np.sin(i / 10.0))
            arr[i, j, 1] = int(128 + 127 * np.cos(j / 15.0))
            arr[i, j, 2] = int(128 + 127 * np.sin((i + j) / 20.0))

    img_a = Image.fromarray(arr)
    buf_a = io.BytesIO()
    img_a.save(buf_a, format="PNG")
    img_bytes_a = buf_a.getvalue()

    # Re-encoded / slightly resampled repost copy (typical social media downsampling)
    buf_b = io.BytesIO()
    img_a.resize((180, 180)).resize((200, 200)).save(buf_b, format="JPEG", quality=80)
    img_bytes_b = buf_b.getvalue()

    bundle_a = fingerprint_engine.generate_fingerprints(img_bytes_a)
    bundle_b = fingerprint_engine.generate_fingerprints(img_bytes_b)

    comparison = fingerprint_engine.compare_fingerprints(bundle_a, bundle_b)
    assert comparison["is_misuse_detected"] is True
    assert comparison["phash_hamming_distance"] <= 10
    assert comparison["visual_similarity_pct"] >= 70.0
