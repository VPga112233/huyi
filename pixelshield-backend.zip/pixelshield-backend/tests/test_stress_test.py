"""Tests for Feature 03: Social Media Stress Test Simulator."""
import io
import pytest
import numpy as np
from PIL import Image

from app.engine.stress_test import simulator


def create_gradient_test_image(width=400, height=300):
    """Creates a natural smooth gradient test image."""
    y, x = np.mgrid[0:height, 0:width]
    r = (x * 255 // width).astype(np.uint8)
    g = (y * 255 // height).astype(np.uint8)
    b = ((x + y) * 128 // (width + height)).astype(np.uint8)
    arr = np.stack([r, g, b], axis=-1)
    img = Image.fromarray(arr)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def test_whatsapp_compression_pipeline():
    img_bytes = create_gradient_test_image(1800, 1200)
    compressed = simulator.simulate_whatsapp(img_bytes)
    assert len(compressed) > 0

    comp_img = Image.open(io.BytesIO(compressed))
    w, h = comp_img.size
    assert max(w, h) <= 1600
    assert comp_img.format == "JPEG"


def test_instagram_compression_pipeline():
    img_bytes = create_gradient_test_image(800, 800)
    compressed = simulator.simulate_instagram(img_bytes)
    assert len(compressed) > 0

    comp_img = Image.open(io.BytesIO(compressed))
    w, h = comp_img.size
    assert w == 1080
    assert comp_img.format == "JPEG"


def test_screenshot_compression_pipeline():
    img_bytes = create_gradient_test_image(500, 500)
    compressed = simulator.simulate_screenshot(img_bytes)
    assert len(compressed) > 0

    comp_img = Image.open(io.BytesIO(compressed))
    assert comp_img.size == (500, 500)
    assert comp_img.format == "JPEG"


def test_full_stress_test_resilience_scoring():
    orig_bytes = create_gradient_test_image(300, 300)
    # Simulate cloaked by adding small random noise
    orig_img = Image.open(io.BytesIO(orig_bytes))
    orig_np = np.array(orig_img).astype(np.int16)
    noise = np.random.randint(-6, 7, orig_np.shape)
    cloaked_np = np.clip(orig_np + noise, 0, 255).astype(np.uint8)

    buf = io.BytesIO()
    Image.fromarray(cloaked_np).save(buf, format="PNG")
    cloaked_bytes = buf.getvalue()

    results = simulator.run_stress_test(orig_bytes, cloaked_bytes)
    assert "overall_resilience_score" in results
    assert "platforms" in results
    assert "whatsapp" in results["platforms"]
    assert "instagram" in results["platforms"]
    assert "screenshot" in results["platforms"]

    whatsapp_res = results["platforms"]["whatsapp"]
    assert "resilience_score" in whatsapp_res
    assert "post_compression_psnr_db" in whatsapp_res
    assert whatsapp_res["post_compression_psnr_db"] > 25.0
