"""Tests for Feature 01 & 02: Adversarial Cloaking Engine."""
import io
import pytest
import numpy as np
from PIL import Image

from app.engine.cloaker import cloaking_engine
from app.core.limits import calculate_psnr, calculate_ssim


def create_sample_image(width=128, height=128):
    """Creates a sample RGB test image with gradients and edges."""
    arr = np.zeros((height, width, 3), dtype=np.uint8)
    for y in range(height):
        for x in range(width):
            arr[y, x, 0] = (x * 2) % 256
            arr[y, x, 1] = (y * 2) % 256
            arr[y, x, 2] = ((x + y)) % 256
    img = Image.fromarray(arr)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue(), arr


def test_cloaker_generates_valid_cloaked_image():
    img_bytes, orig_arr = create_sample_image(128, 128)
    cloaked_bytes, metrics, assessment = cloaking_engine.cloak(
        image_bytes=img_bytes,
        preset="standard",
        custom_steps=5  # Fast test step
    )

    assert len(cloaked_bytes) > 0
    # Verify valid image format
    cloaked_pil = Image.open(io.BytesIO(cloaked_bytes))
    assert cloaked_pil.size == (128, 128)
    assert cloaked_pil.mode == "RGB"

    # Verify metrics
    assert "psnr_db" in metrics
    assert "ssim_index" in metrics
    assert "l_inf_raw" in metrics
    assert metrics["psnr_db"] > 25.0
    assert 0.85 <= metrics["ssim_index"] <= 1.0

    # Verify threat assessment
    assert assessment["shield_preset"] == "standard"
    assert len(assessment["protected_vectors"]) >= 3
    assert len(assessment["vulnerability_boundaries"]) >= 2


def test_jnd_mask_computation():
    img_bytes, _ = create_sample_image(64, 64)
    pil_img = Image.open(io.BytesIO(img_bytes))
    import torch
    x_tensor = torch.from_numpy(np.array(pil_img)).permute(2, 0, 1).unsqueeze(0).float() / 255.0
    x_tensor = x_tensor.to(cloaking_engine.device)

    jnd_mask = cloaking_engine.compute_jnd_mask(x_tensor)
    assert jnd_mask.shape == x_tensor.shape
    assert torch.all(jnd_mask >= 0.35)
    assert torch.all(jnd_mask <= 1.65)


def test_client_parameters_export():
    params = cloaking_engine.get_client_parameters(preset="high")
    assert params["protocol_version"] == "1.0-ZK-ONDEVICE"
    assert params["preset"] == "high"
    assert "epsilon" in params
    assert "steps" in params
    assert "onnx_model_urls" in params
    assert "zero_knowledge_guarantee" in params
